interface AssocStringString {
    [key: string]: string;
}

interface playerData {
    name: string;
    score: number;
}