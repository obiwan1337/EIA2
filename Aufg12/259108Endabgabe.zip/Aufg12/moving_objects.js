var invino;
(function (invino) {
    class Moving_objects {
        constructor() {
            this.init();
        }
        init() {
            this.setup();
        }
        setup() { }
    }
    invino.Moving_objects = Moving_objects;
})(invino || (invino = {}));
//# sourceMappingURL=moving_objects.js.map