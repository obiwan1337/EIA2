namespace invino {
    export class Moving_objects {
        y: number;
        x: number;
        dx: number;
        dy: number;

        constructor() {
            this.init();
        }

        init(): void {
            this.setup();
        }
        setup(): void { }
    }
}
